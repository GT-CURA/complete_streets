import numpy as np

from neurvps.box import Box

# C is a dict storing all the configuration
C = Box()

# shortcut for C.model
M = Box()
